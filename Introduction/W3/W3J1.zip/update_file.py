def update_file(n, k):
    hour = 0
    updated_computers = 1

    while updated_computers < n:
        temp = min(k, updated_computers)
        updated_computers += temp
        hour += 1

    return hour



print(update_file(8, 3))
print(update_file(6, 6))
print(update_file(7, 1))
print(update_file(1, 1))


